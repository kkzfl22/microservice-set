while true; 
do curl "http://localhost:8989/hystrix-examples-webapp/"; 
done