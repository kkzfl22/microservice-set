package io.spring2go.piggymetrics.statistics.domain.timeseries;

public enum StatisticMetric {

	INCOMES_AMOUNT, EXPENSES_AMOUNT, SAVING_AMOUNT

}
