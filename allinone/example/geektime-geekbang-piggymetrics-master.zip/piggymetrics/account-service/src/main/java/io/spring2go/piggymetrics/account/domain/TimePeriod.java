package io.spring2go.piggymetrics.account.domain;

public enum TimePeriod {

	YEAR, QUARTER, MONTH, DAY, HOUR

}
