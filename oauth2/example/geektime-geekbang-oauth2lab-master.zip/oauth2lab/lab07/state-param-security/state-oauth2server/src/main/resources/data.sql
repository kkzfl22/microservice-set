insert into userinfo (username, password) values ('bobo', 'xyz');
insert into userinfo (username, password) values ('attacker', 'xyz');
