package io.spring2go.oauth2.clientstate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientStateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientStateApplication.class, args);
	}
}
