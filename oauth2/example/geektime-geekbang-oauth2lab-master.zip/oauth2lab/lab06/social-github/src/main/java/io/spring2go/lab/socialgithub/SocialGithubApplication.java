package io.spring2go.lab.socialgithub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialGithubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialGithubApplication.class, args);
	}
}
