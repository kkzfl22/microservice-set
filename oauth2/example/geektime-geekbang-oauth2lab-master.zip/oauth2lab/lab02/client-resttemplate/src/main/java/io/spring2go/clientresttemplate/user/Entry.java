package io.spring2go.clientresttemplate.user;

public class Entry {

    private String value;

    public Entry(String value) {
        super();
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
