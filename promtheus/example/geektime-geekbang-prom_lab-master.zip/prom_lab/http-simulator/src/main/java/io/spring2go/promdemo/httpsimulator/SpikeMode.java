package io.spring2go.promdemo.httpsimulator;

public enum SpikeMode {
	
	OFF, ON, RANDOM
	
}
